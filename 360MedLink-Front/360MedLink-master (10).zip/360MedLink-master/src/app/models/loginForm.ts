export class LoginForm {
  public username:string;
  public password:string;
  constructor() {}

}
